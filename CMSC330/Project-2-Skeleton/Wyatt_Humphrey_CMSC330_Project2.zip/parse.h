// CMSC 330 Advanced Programming Languages
// Project 2 Skeleton
// UMGC CITE
// Spring 2023

// This file contains the function prototype of the parseName function whose body is defined in parse.cpp.

string parseName(stringstream& in);